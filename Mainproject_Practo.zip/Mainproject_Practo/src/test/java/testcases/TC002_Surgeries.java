package testcases;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

public class TC002_Surgeries extends Basetest
{
	@Test(priority = 0,groups={"smoke","regression"})
	public void getSurgeries() throws InterruptedException, IOException
	{
		Boolean status = surp.getSurgeries();
		Assert.assertEquals(true, status);
	}
	@Test(priority = 1,dependsOnMethods= {"getSurgeries"},groups={"regression"})
	public void printSurgeries() throws InterruptedException, IOException
	{
		Boolean status = surp.printsurgeries();
		Assert.assertEquals(true, status);
	}
}
