package testcases;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

public class Test001_Search_Doctor extends Basetest
{
	@Test(priority = 0,groups= {"smoke","regression"})
	public void selectLocation() throws InterruptedException, IOException
	{
		FullScreenshot("first");
		fp.selectlocality();
	}
	@Test(priority = 1,dependsOnMethods= {"selectLocation"},groups= {"smoke","regression"})
	public void selectSpeciality() throws InterruptedException, IOException
	{
		Boolean status =fp.selectspecialty();
		Assert.assertEquals(true, status);
	}
	@Test(priority = 2,dependsOnMethods= {"selectSpeciality"},groups= {"regression"})
	public void selectStories() throws InterruptedException, IOException
	{
		Boolean status =sp.storyselection();
		FullScreenshot("Story");
		Thread.sleep(2000);
		Assert.assertEquals(true, status);
	}
	@Test(priority = 3,dependsOnMethods= {"selectSpeciality"},groups= {"regression"})
	public void selectExperience() throws InterruptedException, IOException
	{
		Boolean status =sp.selectexp();
		Thread.sleep(2000);
		Assert.assertEquals(true, status);
	}
	@Test(priority = 4,dependsOnMethods= {"selectSpeciality"},groups= {"regression"})
	public void selectFees() throws InterruptedException, IOException
	{
		Boolean status =sp.selectfees();
		Thread.sleep(5000);
		Assert.assertEquals(true, status);
	}
	@Test(priority = 5,dependsOnMethods= {"selectSpeciality"},groups= {"regression"})
	public void selectAvailabilty() throws InterruptedException, IOException
	{
		Boolean status =sp.selectavailability();
		Thread.sleep(3000);
		Assert.assertEquals(true, status);
	}
	
	@Test(priority = 6,dependsOnMethods= {"selectSpeciality"},groups= {"regression"})
	public void selectRelevance() throws InterruptedException, IOException
	{
		Boolean status =sp.selectrelevance();
		Thread.sleep(3000);
		Assert.assertEquals(true, status);
		
	}
	
	@Test(priority = 7,dependsOnMethods= {"selectSpeciality","selectRelevance","selectAvailabilty","selectFees","selectExperience","selectStories"},groups= {"regression"})
	public void getDocName() throws IOException, InterruptedException
	{
		Boolean status = sp.printdocname();
		Thread.sleep(2000);
		Assert.assertEquals(true, status);
		
	}
	
}
