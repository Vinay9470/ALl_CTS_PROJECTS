package testcases;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import utils.Excelutils;

public class TC003_Check_Demo_Form extends Basetest
{
	@Test(priority = 0,groups= {"smoke","regression"})
	public void getform()
	{
		Boolean status = dp.getform();
		Assert.assertEquals(true, status);
		
	}
	@Test(priority = 1,dependsOnMethods= {"getform"},groups= {"smoke","regression"},dataProvider = "Demodata")
    public void fillform(String name, String orgName, String number, String email, String orgSize, String interest) throws InterruptedException, IOException
    {
        dp.getdemo(name, orgName, number, email, orgSize, interest);
        FullScreenshot(name);
        Boolean status = dp.submitbuttonstatus();
        int i = 1;
		if(status == true)
		{
			dp.clickdemo();
			Thread.sleep(20000);
			FullScreenshot("demoresult"+i);
			i++;
			Boolean thankstatus = dp.getThankstatus();
			Assert.assertEquals(true, thankstatus);
			System.out.println("Massage is displayed :" +dp.getMsg());
			driver.navigate().back();
			driver.navigate().refresh();
			Thread.sleep(5000);
			
		}
		else
		{
			System.out.println("Submit button is not Enabled\nEnter valid Input.");
		}
		dp.clear();
        
    }
	

	@DataProvider(name = "Demodata")
	public String[][] data() throws IOException
	{
		String file = ".\\Testdata\\HospitalDemo.xlsx";
	    int row = Excelutils.getRowCount(file, "Sheet1");
	    String demodata[][]= new String[row+1][6];
	    for(int i = 0; i <= row; i++) 
	    {
	        String data = Excelutils.getCellData(file, "Sheet1", i, 0).toString();
	        String dataarr[] = data.split(":");
	        for(int j = 0; j < dataarr.length; j++) 
	        {
	            String ddata= dataarr[j];
	            demodata[i][j] = ddata;
	        }
	    }
	    return demodata; 
	}
}
