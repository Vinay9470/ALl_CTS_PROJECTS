package testcases;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;
import java.util.logging.LogManager;

import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;

import pageojects.Demopage;
import pageojects.FirstPage;
import pageojects.SearchPage;
import pageojects.Surgeriespage;

public class Basetest 
{
	static WebDriver driver;
	public static String target;
	public Properties p;
	public Logger logger;
	FirstPage fp;
	SearchPage sp;
	Surgeriespage surp;
	Demopage dp;
	
	
	@BeforeClass
	@Parameters({"Browser"})
	public void Driversetup(String browser) throws IOException
	
	{
		//creating the driver
		if(browser.equalsIgnoreCase("chrome"))
		{
			System.out.println("-----------------\nTesting in Chrome.\n-------------------");
			driver = new ChromeDriver();
		}
		else if(browser.equalsIgnoreCase("edge"))
		{
			System.out.println("-----------------\\nTesting in Edge.\\n-------------------");
			driver = new EdgeDriver();
		}
		else
		{
			System.out.println("Wrong browser parameter in test xml");
		}
		//opening the webpage
		Properties p = new Properties();
		FileInputStream file = new FileInputStream(".\\src\\test\\resources\\Config.properties");
		p.load(file);
		driver.get(p.getProperty("AppURL"));
		
		
		//delete all cookies
		driver.manage().deleteAllCookies();
		//maximizing the window
		driver.manage().window().maximize();
		//assigning an implicit wait
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		//assigning driver to the first page
		fp = new FirstPage(driver);
		sp = new SearchPage(driver);
		surp = new Surgeriespage(driver);
		dp = new Demopage(driver);
		
		
	}
	
	public String FullScreenshot( String name) throws IOException
	{
		TakesScreenshot ts = (TakesScreenshot) driver;
		File src = ts.getScreenshotAs(OutputType.FILE);
		target = System.getProperty("user.dir")+"\\Screenshots\\"+name+".png";
		File trg = new File (target);
		src.renameTo(trg);
		return target;

	}
	public void ScreenshotElement(WebElement we) throws IOException
	{
		File src = we.getScreenshotAs(OutputType.FILE);
		File trg = new File ("./Screenshots/"+we.getText()+".png");
		FileUtils.copyFile(src, trg);
	}
	
	@AfterClass
	public void close()
	{
		driver.quit();
	}
	
}
