package pageojects;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import utils.Excelutils;

public class FirstPage extends Basepage 
{
	WebDriver driver;
	String file = ".\\Testdata\\Hospitalinput.xlsx";
	//constructor
	public FirstPage(WebDriver driver)
	{
		super(driver);
	}
	
	//elements
	@FindBy(xpath = "//input[@data-input-box-id=\"omni-searchbox-locality\"]") WebElement locality_loc;
	@FindBy(xpath = "//div[@data-qa-id=\"omni-suggestion-main\"]") List<WebElement> locality_list_loc;
	@FindBy(xpath = "//input[@data-input-box-id=\"omni-searchbox-keyword\"]") WebElement speciality_loc;
	@FindBy(xpath = "//div[@class=\"c-omni-suggestion-item__content__title\"]") List<WebElement> Specialities_loc;
	
	//methods
	
	
	//select locality
	public void selectlocality() throws InterruptedException, IOException
	{
		Thread.sleep(1000);
		locality_loc.clear();
		Thread.sleep(1000);
		String location = Excelutils.getCellData(file, "Sheet1", 0, 1);
		locality_loc.sendKeys(location);
		Thread.sleep(1000);
		for(WebElement loc:locality_list_loc)
		{
			String locality = loc.getText();
			if(locality.equalsIgnoreCase(location))
			{
				loc.click();
				return;
			}
		}
	}
	
	//select specialty
	
	public Boolean selectspecialty() throws InterruptedException, IOException
	{
		Thread.sleep(1000);
		speciality_loc.click();
		Boolean status = false;
		Thread.sleep(2000);
		String specalist = Excelutils.getCellData(file, "Sheet1", 1, 1);
		for(WebElement ele: Specialities_loc)
		{
			String elementtext = ele.getText();
			if(elementtext.equalsIgnoreCase(specalist))
			{
				ele.click();
				status = true;
				return status;
			}
		}
		return status;
	}
	

}
