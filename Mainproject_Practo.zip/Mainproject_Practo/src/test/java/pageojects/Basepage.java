package pageojects;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class Basepage 
{

	WebDriver driver;
	JavascriptExecutor js;
	TakesScreenshot ts;
	
	//constructor assigning the driver
	public Basepage(WebDriver driver)
	{
		this.driver = driver;
		js = (JavascriptExecutor) driver;
		PageFactory.initElements(driver,this);
		
	}
	
	
	public void FullScreenshot( String name) throws IOException
	{
		TakesScreenshot ts = (TakesScreenshot) driver;
		File src = ts.getScreenshotAs(OutputType.FILE);
		File trg = new File ("./Screenshots/"+name+".png");
		FileUtils.copyFile(src, trg);

	}
}
