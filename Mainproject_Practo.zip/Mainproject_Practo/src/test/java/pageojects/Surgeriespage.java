package pageojects;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import utils.Excelutils;

public class Surgeriespage extends Basepage
{
	WebDriver driver;
	String File = ".\\Testdata\\Surgeries.xlsx";
	
	//constructor
	public Surgeriespage(WebDriver driver)
	{
		super(driver);
		
	}
	
	//elements
	@FindBy(xpath = "//p[@data-qa-id=\"surgical-solution-ailment-name\"]") List<WebElement> surgerie_list_loc ;
	
	@FindBy (xpath = "//div[text()=\"Surgeries\"]") WebElement surgeries_loc;
	
	//methods
	
	
	//geting  types of surgeries
	public Boolean getSurgeries() throws InterruptedException
	{
		Boolean status = false;
		if(surgeries_loc.isDisplayed())
		{
			surgeries_loc.click();
			status = true;
		}
	    Thread.sleep(3000);
		return status;
	}
	
	// Printing types of surgeries
	public Boolean printsurgeries() throws InterruptedException, IOException
	{
        js.executeScript("window.scrollBy(0,500)", "");
        FullScreenshot("Surgerie1");
        Thread.sleep(3000);
        js.executeScript("window.scrollBy(0,200)", "");
        FullScreenshot("Surgerie2");
        Thread.sleep(1000);  // Added delay
        Boolean status = false;
        if(surgerie_list_loc.get(4).isDisplayed())
        {
        	status = true;
        }
	    String sur = "The List of surgeries displayed in the website:";
	    System.out.println(sur);
	    Excelutils.setCellData(File, "Sheet1", 0, 0, sur);
	    for(int i =0 ;i<surgerie_list_loc.size();i++)
        {
	    	WebElement surgerie = surgerie_list_loc.get(i);
	    	System.out.println(surgerie.getText());
            Excelutils.setCellData(File, "Sheet1", i+1, 0, surgerie.getText());
        }
	    return status;
	    
	}

}
