package pageojects;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import utils.Excelutils;

public class SearchPage extends Basepage
{
	String file = ".\\Testdata\\HospitalInput.xlsx";
	String outfile = ".\\Testdata\\Hospital.xlsx"; 
	//constructor
	public SearchPage(WebDriver driver)
	{
		super(driver);
	}
	
	//WebElements
	@FindBy(xpath = "//div[@data-qa-id=\"doctor_review_count_section\"]") WebElement StoryButton_loc;
	@FindBy(xpath =  "//ul[@data-qa-id=\"doctor_review_count_list\"]//span") List<WebElement> stories_list;
	@FindBy(xpath = "//span[@data-qa-id=\"years_of_experience_selected\"]") WebElement experianceButton_loc;
	@FindBy(xpath = "//ul[@data-qa-id=\"years_of_experience_list\"]//span") List<WebElement> Experience_list;
	@FindBy(xpath = "//i[@class=\"u-transition--transform u-d-inlineblock icon-ic_dropdown\"]") WebElement filter_loc;
	@FindBy(xpath = "//span[@data-qa-id=\"Fees_title\"]/following-sibling :: label/span") List<WebElement> fees_list_loc;
	@FindBy(xpath = "//span[@data-qa-id=\"Availability_title\"]/following-sibling::label/span") List<WebElement> availabily_loc;
	@FindBy(xpath = "//span[@class=\"c-sort-dropdown__selected c-dropdown__selected\"]") WebElement relevance_loc;
	@FindBy(xpath = "//ul[@data-qa-id=\"sort_by_list\"]/li") List<WebElement> sort_by_loc;
	@FindBy(xpath = "//h2[@class='doctor-name']")
	List<WebElement> dentists;
	
	@FindBy(xpath = "//div[@class='u-grey_3-text']/div[2]")
	List<WebElement> dentistsExperience;
	
	@FindBy(xpath = "//span[@data-qa-id='practice_locality']")
	List<WebElement> dentistsLocation;
	
	@FindBy(xpath = "//span[@data-qa-id='doctor_clinic_name']")
	List<WebElement> dentistsClinic;
	
	@FindBy(xpath = "//span[@data-qa-id='doctor_recommendation']")
	List<WebElement> dentistsDentistsRating;
	
	@FindBy(xpath = "//h1[@class='u-xx-large-font u-bold']")
	WebElement totalDoctors;
	
	//methods
	
	//select number of stories
	public Boolean storyselection() throws InterruptedException, IOException
	{
		StoryButton_loc.click();
		Boolean status = false;
		Thread.sleep(2000);
		for(WebElement element:stories_list)
		{
			String story = element.getText();
			String selectstory = Excelutils.getCellData(file, "Sheet1", 0, 0);
			if(story.equalsIgnoreCase(selectstory))
			{
				element.click();
				status = true;
				return status;
				
			}
		}
		return status;
		
	}
	
	//select experience
	
	public Boolean selectexp() throws InterruptedException, IOException
	{
		experianceButton_loc.click();
		Boolean status = false;
		Thread.sleep(2000);
		for(WebElement experiance: Experience_list)
		{
			String ExperianceText = experiance.getText();
			String selectexp = Excelutils.getCellData(file, "Sheet1", 1, 0);
			if(ExperianceText.contains(selectexp))
			{
				experiance.click();
				status = true;
				return status;
			}
		}
		return status;
	}
	
	//selectingfees
	public Boolean selectfees() throws InterruptedException, IOException 
	{
		filter_loc.click();
		Boolean status = false;
		FullScreenshot("Searching");
		Thread.sleep(2000);
		for(WebElement fees: fees_list_loc)
		{
			String fee = fees.getAttribute("data-qa-id");
			String selectfees = Excelutils.getCellData(file, "Sheet1", 2, 0);
			if(fee.contains(selectfees))
			{
				fees.click();
				status = true;
				return status;
			}
		}
		return status;
		
	}
	
	//selecting availability
	public Boolean selectavailability() throws InterruptedException, IOException
	{
		filter_loc.click();
		Boolean status = false;
		Thread.sleep(2000);
		for(WebElement fees: availabily_loc)
		{
			String fee = fees.getAttribute("data-qa-id");
			String selectdate = Excelutils.getCellData(file, "Sheet1", 3, 0);
			if(fee.contains(selectdate))
			{
				fees.click();
				status = true;
				return status;
			}
		}
		return status;
	}
	
	
	//selecting relavance
	public Boolean selectrelevance() throws InterruptedException, IOException
	{
		relevance_loc.click();
		Boolean status = false;
		FullScreenshot("Relevance");
		Thread.sleep(1000);
		for(WebElement sort : sort_by_loc)
		{
			String sorting = sort.getAttribute("aria-label");
			String selectrelevance = Excelutils.getCellData(file, "Sheet1", 4, 0);
			if(sorting.contains(selectrelevance))
			{
				sort.click();
				status = true;
				return status;
			}
		}
		return status;
	}
	
	//printing doctor name 
	public Boolean printdocname() throws IOException, InterruptedException
	{
		Boolean status = false;
		Thread.sleep(3000);
		js.executeScript("window.scrollBy(0,500)", "");
		if(totalDoctors.isDisplayed())
		{
			status = true;
		}
		System.out.println("Total Doctors :"+totalDoctors.getText());
		for(int i = 1; i<=5;i++)
		{
			js.executeScript("window.scrollBy(0,300)", "");
			String name = "Result"+i;
			FullScreenshot(name);
			WebElement docname = dentists.get(i);
			WebElement docexperience = dentistsExperience.get(i);
			WebElement doclocation = dentistsLocation.get(i);
			WebElement docclinic = dentistsClinic.get(i);
			WebElement docrating =dentistsDentistsRating.get(i);
			System.out.println(docname.getText());
			System.out.println(docexperience.getText());
			System.out.println(doclocation.getText());
			System.out.println(docclinic.getText());
			System.out.println("Rating "+docrating.getText());
			Excelutils.setCellData(outfile, "Sheet1", 0, 0, "Doctor's details");
			Excelutils.setCellData(outfile, "Sheet1", i, 0, docname.getText());
			Excelutils.setCellData(outfile, "Sheet1", i, 0, docexperience.getText());
			Excelutils.setCellData(outfile, "Sheet1", i, 0, doclocation.getText());
			Excelutils.setCellData(outfile, "Sheet1", i, 0, docclinic.getText());
			Excelutils.setCellData(outfile, "Sheet1", i, 0, "Rating "+docrating.getText());
			System.out.println("-----------------------");
			Thread.sleep(5000);
		}
		return status;
	}
	
	
	
	
}
