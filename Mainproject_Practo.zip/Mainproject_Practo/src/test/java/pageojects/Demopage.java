package pageojects;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;


public class Demopage extends Basepage
{
	//CONSTRUCTOR
	WebDriver driver;
	public Demopage(WebDriver driver)
	{
		super(driver);
	}
	
	//WEBELEMENT
	@FindBy(xpath = "//span[text() = \"For Corporates\"]") WebElement corporate_loc;
	@FindBy(xpath = "//a[text() = \"Health & Wellness Plans\"]") WebElement health_loc;
	@FindBy(xpath = "//*[@id=\"header\"]/div[2]/div/form/button") WebElement demo_button_loc;
	@FindBy(id="name") WebElement name_loc;
	@FindBy(id="organizationName") WebElement org_name_loc;
	@FindBy(id="contactNumber") WebElement number_loc;
	@FindBy(id="officialEmailId") WebElement email_loc;
	@FindBy(id="organizationSize") WebElement orgsize_loc;
	@FindBy(id="interestedIn") WebElement interest_loc;
	@FindBy(xpath = "//div[text() = \"THANK YOU\"]") WebElement thank_loc;
	
	
	//methods
	//geting for 
	public Boolean getform()
	{
		corporate_loc.click();
		health_loc.click();
		Boolean status = false;
		if(name_loc.isDisplayed())
		{
			status = true;
		}
		return status;
	}
	
	
	public void getdemo(String name, String orgName, String number, String email, String orgSize, String interest) throws IOException
	{
		FullScreenshot("form");
	    name_loc.sendKeys(name);
	    org_name_loc.sendKeys(orgName);
	    number_loc.sendKeys(number);
	    email_loc.sendKeys(email);
	    Select orgsizeselect = new Select(orgsize_loc);
	    orgsizeselect.selectByVisibleText(orgSize);
	    Select interestSelect = new Select(interest_loc);
	    interestSelect.selectByVisibleText(interest);
	}
	public void clear()
	{
		name_loc.clear();;
	    org_name_loc.clear();
	    number_loc.clear();
	    email_loc.clear();
	}
	
	
	public boolean submitbuttonstatus()
	{
			return demo_button_loc.isEnabled();
		
	}
	
	public void clickdemo()
	{
		demo_button_loc.click();
	}
	
	public Boolean getThankstatus()
	{
		return thank_loc.isEnabled();
	}
	public String getMsg()
	{
		return thank_loc.getText();
		
	}
}
