package testNG_40;

import org.testng.annotations.*;


public class firstTest {

	@BeforeMethod
	void login()
	{
		System.out.println("Login..");
	}
	
	@Test(priority=1)
	void search()
	{
		System.out.println("Search....");
		
	}
	
	@Test(priority=2)
	void advancedsearch() 
	{
		System.out.println("Advance search..");
	}
	@AfterMethod
	void logout() 
	{
		System.out.println("logout...");
	}
}
