package day28;

import java.time.Duration;
//import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class PageNation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://testautomationpractice.blogspot.com/");
		
		driver.manage().window().maximize();
		
		
	int tableno= driver.findElements(By.xpath("//ul[@class='pagination']/li")).size();
	System.out.println(tableno);
	
	for(int i=1; i<=tableno; i++)
	{
	driver.findElement(By.xpath(""))
	
	int rows =driver.findElements(By.xpath("//table[@name='BookTable']//tr")).size();
	int columns = driver.findElements(By.xpath("//table[@name='BookTable']//th")).size();
	
	for(int r=1 ; r<=rows;r++) {
		for(int c ; c<=columns; c++) {
			
			String  data= driver.findElement(By.xpath("//table[@name=\"BookTable\"]//tr[2]//td[3]")).getText();
			
			System.out.println("data from table" +data);
			
		}
		
	}
	
	}
	
	
		
	}

}
