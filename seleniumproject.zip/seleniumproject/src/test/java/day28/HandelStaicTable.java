package day28;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandelStaicTable {

	public static void main(String[] args) {
	
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://testautomationpractice.blogspot.com/");
		
		driver.manage().window().maximize();
		
		// finding total number of rows 
		
	//List<WebElement>rows=driver.findElements(By.xpath("//table[@name='BookTable']//tr"));
		//rows.size();
		 
		
		// Approach 1 
	int rows=driver.findElements(By.xpath("//table[@name='BookTable']//tr")).size();
	//System.out.println("size of rows " + rows);
		
		//2) Find total number of columns 
		
		//int columns =driver.findElements(By.xpath("//table[@name='BookTable']//th")).size();
		
		//System.out.println("total no of columns "+ columns);
		
		
		//3 read specific row and columns data 
		
		//String  value =driver.findElement(By.xpath("//table[@name='BookTable']//tr[4]//td[4]")).getText();
		//System.out.println("total no of value in "+value);
		
		//read data from all rows and columns 
		
	/*	for(int i=2;i<=rows;i++) {
			
			
			for(int j=1;j<=columns;j++)
			{

				String  value =driver.findElement(By.xpath("//table[@name='BookTable']//tr["+i+"]//td["+j+"]")).getText();
				System.out.print(value+"  ");
				
			}
			
			System.out.println();
		}
		*/
		
		//5) Print book names whose author is Amit
		
	/*	for(int i=2;i<=rows;i++) {
			
		
				String author=driver.findElement(By.xpath("//table[@name='BookTable']//tr["+i+"]//td[2]")).getText();

				
				if(author.equals("Amit")) {
					String BookName=driver.findElement(By.xpath("//table[@name='BookTable']//tr["+i+"]//td[1]")).getText();
					System.out.println(author+"    " +BookName);
				}
			}
		
		*/
		//6) find sum of prices for all the books
		
		
		int sum =0;
		for(int i=2;i<=rows;i++) {
			String  price = driver.findElement(By.xpath("//table[@name='BookTable']//tr["+i+"]//td[4]")).getText();
			
			System.out.println(price);
			
			sum= sum+Integer.parseInt(price);
			
		}
		
		
		System.out.println("sum of price "+sum );
		
	
	}

}
