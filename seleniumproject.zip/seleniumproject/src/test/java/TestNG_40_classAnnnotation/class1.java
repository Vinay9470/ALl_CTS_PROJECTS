package TestNG_40_classAnnnotation;

import org.testng.annotations.*;

public class class1 {

	@Test
	void  Abc() 
	{
		System.out.println("this is abc from class 1");
	}
	@BeforeTest
	void m()
	{
		System.out.println("this is brfore test method");
	}
}
