package TestNG_40_classAnnnotation;

import org.testng.annotations.* ;

public class class2
{
@Test	
 void xyz() 
 {
	 System.out.println("this is xyz from class 2");
 }
@AfterTest
void n() {
	System.out.println("this is after test method..");
}
	
}
