package day_39;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;

import io.github.bonigarcia.wdm.WebDriverManager;
//Test Methods 
public class loginTest {
	WebDriver driver;
	LoginPage2 lp;
	@BeforeClass
	void setup()
	{
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/lo");
		
	}
	@Test(priority=1)
	void testlogo()
	{
	 lp= new LoginPage2(driver);//when we create objet ,it will try to invoke constructor
	                               ////so we have to pass driver
	
	Assert.assertEquals(lp.checklogpresencre(), true);									
	 
	 
	}
	@Test(priority=2)
	void testLogin() 
	{
		lp.setUserName("Admin");
		lp.setPassword("admin123");
		lp.clickSubmit();
		
		Assert.assertEquals(driver.getTitle(),"OrangeHRM");
    }
	@AfterClass
	void teardown()
	{
		driver.quit();
	}
	
	
}