package day_39;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
//import org.testng.Assert;


//page object class  intract whit webpage 
public class LoginPage2 {

		
		WebDriver driver;
		//Constructor
		
		LoginPage2(WebDriver driver)
		{
			this.driver= driver;
		}
		
		//locators
		
		By img_logo_loc = By.xpath("//img[@alt='company-branding']");	
		By txt_username_loc = By.name("username");
		By txt_password_loc =By.name("password");
		By btn_Submit_loc=By.xpath("//button[contains (@class,'oxd-button oxd-button')]");
		
		//Action methods
		public void setUserName(String username)
		{
			driver.findElement(txt_username_loc).sendKeys(username);
	    }
		
		public void setPassword(String password)
		{
			driver.findElement(txt_password_loc).sendKeys(password);
			
		}
		
		public void  clickSubmit()
		{
			driver.findElement(btn_Submit_loc).click();
		}
		
		public boolean checklogpresencre()
		{
			
		  boolean status= driver.findElement(btn_Submit_loc).isDisplayed();
			 
			return status;
		}
		
		
}
