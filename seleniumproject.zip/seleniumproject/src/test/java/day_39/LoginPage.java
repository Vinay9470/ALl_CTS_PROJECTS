package day_39;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
//import org.testng.Assert;


//page object class  intract whit webpage 
public class LoginPage {

		
		WebDriver driver;
		

		//Constructor
		LoginPage(WebDriver driver)
		{
			this.driver= driver;
			PageFactory.initElements(driver,this);
			
			
		}
		
		//locators
		
		@FindBy(xpath="//img[@alt='company-branding']") WebElement img_logo;
		@FindBy(name="username") WebElement txt_username_loc;
		@FindBy(name="password") WebElement txt_password_loc;
		@FindBy(xpath="//button[contains (@class,'oxd-button oxd-button')]") WebElement btn_Submit_loc;
		
		
		
		
//		By img_logo_loc = By.xpath("//img[@alt='company-branding']");	
//		By txt_username_loc = By.name("username");
//		By txt_password_loc =By.name("password");
//		By btn_Submit_loc=By.xpath("//button[contains (@class,'oxd-button oxd-button')]");
//		
		//Action methods
		public void setUserName(String username)
		{
			txt_username_loc.sendKeys(username);
	    }
		
		public void setPassword(String password)
		{
			txt_password_loc.sendKeys(password);
			
		}
		
		public void  clickSubmit()
		{
			btn_Submit_loc.click();
		}
		
		public boolean checklogpresencre()
		{
			
		  boolean status= btn_Submit_loc.isDisplayed();
			 
			return status;
		}
		
		
}
