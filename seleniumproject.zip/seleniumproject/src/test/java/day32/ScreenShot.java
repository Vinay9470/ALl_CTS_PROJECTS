package day32;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ScreenShot {

	public static void main(String[] args) throws IOException {
		
		WebDriverManager.chromedriver().setup();
		WebDriver driver =new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://demo.nopcommerce.com/");
		driver.manage().window().maximize();
		
		//Capture full page screenshort
		//TakesScreenshot ts = (TakesScreenshot)driver;
		//ileUtils.copyFile(src, trg);
		
		
		//capture screenshort of specific area from web page
		
		WebElement screenshort=driver.findElement(By.xpath("//*[@id=\"main\"]/div/div/div/div/div[4]"));
		
		File src1=screenshort.getScreenshotAs(OutputType.FILE);
		
		
		File trg1 = new File("C:\\Eclips\\Vinay\\seleniumproject\\Screenshort\\test2.png");
		FileUtils.copyFile(src1, trg1);
		System.out.println("Screenshot has benn taken");
		
		 driver.quit();
		

	}

}
