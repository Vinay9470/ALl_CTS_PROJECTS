package day22;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class GetMethods {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		
		
		// getTittle
		System.out.println("tittle of the page:"+driver.getTitle());
		
		//getCurrentURL
		
	System.out.println("Current URL:"+ driver.getCurrentUrl());
	
	// getPagesSource 
	
	/*
	 System.out.println("Page Source");
	 
	String ps=driver.getPageSource();
	System.out.println(ps);
	System.out.println(ps.contains("html")); /*for checking page source wether html is present or not */
	
	
	
	
	//getWindowHandel
	
	//System.out.print(driver.getWindowHandle()); 
	
	Thread.sleep(4000);
	
	driver.findElement(By.linkText("OrangeHRM, Inc")).click(); //open new browser windows
	
	Set<String> windowsids =driver.getWindowHandles();
	
	for(String winid:windowsids)
	{
		System.out.println(winid);

	}
	
	
	  
		
	}

}
