package Day23;

public class FluentWaitDemo {

	public static void main(String[] args) {
	
		
		
	}

}
