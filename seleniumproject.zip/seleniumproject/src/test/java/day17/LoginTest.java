package day17;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

//import io.github.bonigarcia.wdm.WebDriverManager;

public class LoginTest {

	public static void main(String[] args) throws InterruptedException{
		// TODO Auto-generated method stub
		
		//WebDriverManager.chromedriver().setup();
		
		//1.used to launch our browser
		//ChromeDriver driver = new ChromeDriver(); 
		
		WebDriver driver= new ChromeDriver();
		
		
		//2.open url on the browser
		driver.get("https://opensource-demo.orangehrmlive.com/");
		driver.manage().window().maximize(); // maximizing the page 
		
		Thread.sleep(5000);
		
		//3).Provide username  - Admin
		
		//WebElement txtUsername=driver.findElement(By.name("username"));
		//txtUsername.sendKeys("Admin");
		
		driver.findElement(By.name("username")).sendKeys("Admin");
		
		//4).provide password
		
		driver.findElement(By.name("password")).sendKeys("admin123");
		
		
		//5) click on login button 
		
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div/div[1]/div/div[2]/div[2]/form/div[3]/button")).click();
		
		
		//6) verify the tital of dashboard
		
		String act_title= driver.getTitle();
		String exp_tital ="OrangeHRM";
		
		if(act_title.equals(exp_tital))
		{
			
			System.out.println("Test passed");
			
		}
		
		else
		{
			System.out.println("Failed ");
		}
		
		
		
		
		
		//7. closed browser
		//driver.close();
		driver.quit();
		
		
		
	}

}
