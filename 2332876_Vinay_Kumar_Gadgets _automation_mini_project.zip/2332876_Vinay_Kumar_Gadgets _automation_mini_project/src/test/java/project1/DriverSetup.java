package project1;

import java.util.Scanner;
 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
 
import com.github.dockerjava.api.model.Driver;
 
import io.github.bonigarcia.wdm.WebDriverManager;
 
public class DriverSetup {
 
	public static WebDriver WebDriverSetup()
	{
		System.out.println("--------------------------------------\n      Gadget Automation      \n--------------------------------------");
		System.out.println("Press the button to choose the browser you want to use:\n1.Chrome\n2.Edge\n3.Return");
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		if(n==1)
		{
			WebDriverManager.chromedriver().setup();
			WebDriver driver = new ChromeDriver();
			return driver;
		}
		else if(n==2)
		{
			WebDriverManager.edgedriver().setup();
			WebDriver driver = new EdgeDriver();
			return driver;
		}
		else
		{
			System.out.println("Wrong Input.");
			return null;
		}

 
	}
 
}